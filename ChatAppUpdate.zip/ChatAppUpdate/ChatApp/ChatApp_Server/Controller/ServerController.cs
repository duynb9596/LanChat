﻿using ChatApp_Server.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatApp_Server.Controller
{
	class ServerController
	{
		LanChatDBEntities db = new LanChatDBEntities();
		
		public bool CheckLogin(string username, string password)
		{
			tblUser user = db.tblUsers.Where(i => i.Username.ToString().Equals(username) && i.Password.ToString().Equals(password)).FirstOrDefault(); 
			if (user != null)
				return true;
			return false;
		}

		public bool IsUsernameExisted(string username)
		{
			tblUser user = db.tblUsers.Where(i => i.Username.ToLower().ToString().Equals(username.ToLower())).FirstOrDefault();
			if (user != null)
				return true;
			return false;
		}

		public void SignUp(string username, string password)
		{
			tblUser newUser = new tblUser();
			newUser.Username = username;
			newUser.Password = password;
			db.tblUsers.Add(newUser);
			db.SaveChanges();
		}

        public void InsertHistory(string sender, string content, string recipent, DateTime time)
        {
            //int insert = db.Database.ExecuteSqlCommand("insert into tblHistory (Sender, receipient, Content, Time) values (N'" + sender + "',N'" + recipent + "',N'" + content + "',N'" + time + "')");
			tblHistory history = new tblHistory();
			history.Sender = sender;
			history.Receipient = recipent;
			history.Content = content;
			history.Time = time;
			db.tblHistories.Add(history);
			db.SaveChanges();
		}

        public List <tblHistory>  ViewHistory(string sender, string recipient)
        {
            List<tblHistory> listHistory = new List<tblHistory>();

            listHistory = db.tblHistories.SqlQuery("select id, time, Content, Sender, receipient from  tblHistory where (Sender = '" + sender + "' or Sender = '" + recipient + "' ) and (receipient ='" + sender + "' or receipient = '" + recipient + "' ) order by Time").ToList<tblHistory>();

            return listHistory;
            
        }

		public void InsertGroupName(string nameGroup, string creator)
		{
			tblGroupChat groupChat = new tblGroupChat();
			groupChat.Creator = creator;
			groupChat.Name = nameGroup;
			db.tblGroupChats.Add(groupChat);
			db.SaveChanges();

		}

		public List<string> SelectGroupName(string username)
		{
			List<string> listNameGroup =
						(from tblGroupChatDetail in db.tblGroupChatDetails
						 where tblGroupChatDetail.Username == username
						 select tblGroupChatDetail.GroupName).ToList();
			return listNameGroup;
		}

		public List<string> SelectGroupMember(string nameGroup)
		{
            try
            {
                List<string> listMemberGroup = (from tblGroupChatDetail in db.tblGroupChatDetails
                                                where tblGroupChatDetail.GroupName == nameGroup
                                                select tblGroupChatDetail.Username).ToList();

                return listMemberGroup;
            }
            catch(Exception a)
            {
                MessageBox.Show(a.ToString());
                return null;

            }
			
		}

		public void InsertHistoryGroup(string sender, string nameGroup, string content)
		{
			tblGroupChatHistory history = new tblGroupChatHistory();
			history.Sender = sender;
			history.GroupName = nameGroup;
			history.Content = content;
			history.Time = DateTime.Now;
			db.tblGroupChatHistories.Add(history);
			db.SaveChanges();
		}

		public void InsertGroupMember(string newMember, string groupName)
		{
            try
            {
                tblGroupChatDetail groupChatDetail = new tblGroupChatDetail();
                groupChatDetail.GroupName = groupName;
                groupChatDetail.Username = newMember;
                groupChatDetail.AddedTime = DateTime.Now;
                db.tblGroupChatDetails.Add(groupChatDetail);
                db.SaveChanges();
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
            }
			
		}

		public void DeleteGroupMember(string userName, string groupName)
		{

			// Viet nhu ben duoi thi chay bi loi
			//  tblGroupChatDetail groupChatDetail = new tblGroupChatDetail();           
			//groupChatDetail.Username = userName;
			//groupChatDetail.GroupName = groupName;
			//var entry = db.Entry(groupChatDetail);
			//if (entry.State == System.Data.Entity.EntityState.Detached)
			//    db.tblGroupChatDetails.Attach(groupChatDetail);
			//db.tblGroupChatDetails.Remove(groupChatDetail);           
			//db.SaveChanges();

			//viết như vầy thấy hết lỗi
			db.Database.ExecuteSqlCommand("Delete from tblGroupChatDetail where Username='" + userName + "' and  GroupName = '" + groupName + "'");

		}

		public List<tblGroupChatHistory> ViewHistoryGroupChat(string nameGroup)

		{
			try
			{
				List<tblGroupChatHistory> listHistory = new List<tblGroupChatHistory>();

				listHistory = db.tblGroupChatHistories.SqlQuery("select id, Sender ,Content,GroupName, Time from tblGroupChatHistory where GroupName ='" + nameGroup + "' order by Time").ToList<tblGroupChatHistory>();

				return listHistory;
			}
			catch
			{
				return null;
			}


		}

       


    }
}
