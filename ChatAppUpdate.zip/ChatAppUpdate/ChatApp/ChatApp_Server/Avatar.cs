﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatApp_Server
{
	class Avatar
	{
		string username;
		byte[] byteImage;
		int offset;

		public Avatar(string user, int length)
		{
			username = user;
			byteImage = new byte[length];
			offset = 0;
		}

		public void AppendByteImage(byte[] arrayToAppend)
		{
			Array.Copy(arrayToAppend, 0, byteImage, offset, arrayToAppend.Length);
			offset += arrayToAppend.Length;
		}

		public bool CheckUsername(string user)
		{
			if (username.Equals(user))
				return true;
			return false;
		}

		public byte[] GetByteImage()
		{
			return byteImage;
		}
	}
}
