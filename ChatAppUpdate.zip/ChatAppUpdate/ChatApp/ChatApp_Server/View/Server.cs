﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Configuration;
using ChatApp_Server.Controller;
using ChatApp_Server.Model;

namespace ChatApp_Server
{
	public partial class Server : Form
	{
		private const int PORT_NUMBER = 50000;
		private const int BUFFER_SIZE = 1024;
		//static ASCIIEncoding encoding = new ASCIIEncoding();
		//public static List<TcpClient> clients = new List<TcpClient>();
		//static TcpListener listener;
		private Listener listener;
		public List<Socket> clients = new List<Socket>();
		ServerController serverController;
		string serverIP;
		List<Avatar> listAvatar;

		public Server()
		{
			InitializeComponent();
			listener = new Listener(PORT_NUMBER);
			listener.SocketAccepted += listener_SocketAccepted;
			serverController = new ServerController();
			var host = Dns.GetHostEntry(Dns.GetHostName());
			foreach (var ip in host.AddressList)
			{
				if (ip.AddressFamily == AddressFamily.InterNetwork)
				{
					serverIP = ip.ToString();
				}
			}
			listAvatar = new List<Avatar>();
		}

		private void listener_SocketAccepted(Socket socket)
		{
			var client = new Client(socket);
			client.Received += client_Received;
			client.Disconnected += client_Disconnected;
			string ip = client.Ip.ToString();
			Invoke(new Action(() =>
			{
				var item = new ListViewItem(ip); // ip
				item.SubItems.Add("<<undefined>>"); // nickname
				item.Tag = client;
				livActiveUser.Items.Add(item);
			}));
			clients.Add(socket);
			string message = "Connect|Server|Accepted|" + ip;
			client.Send(message);
			AppendText_txtOutgoingMessage(ip, message);
			
			AppendText_txtConnectMessage(ip, "A client connect to Server on " + socket.RemoteEndPoint.ToString());
		}

		private void client_Disconnected(Client sender)
		{
			Invoke(new Action(() =>
			{
				for (int i = 0; i < livActiveUser.Items.Count; i++)
				{
					var client = livActiveUser.Items[i].Tag as Client;
					if (client.Ip == sender.Ip)
					{  
                        clients.Remove(client._socket);// loai bo ra khoi danh sach
                        Broadcast("Disconnect|" + livActiveUser.Items[i].SubItems[1].Text + "|with|<AllUsers>");
                        livActiveUser.Items.RemoveAt(i);
                        AppendText_txtConnectMessage(sender.Ip.ToString(), "Client " + sender.Ip.ToString() + " has disconnected!");
					}
				}
			}));
		}

		private void client_Received(Client sender, byte[] data)
		{
			var message = Encoding.ASCII.GetString(data).Split('|');
			string mType = message[0];
			string mSender = message[1];
			string mContent = message[2];
			string mRecipient = message[3];
			var fullMessage = Encoding.ASCII.GetString(data);
			string ip = sender.Ip.ToString();
			AppendText_txtIncomingMessage(ip, fullMessage);
			switch (mType)
			{
				case "Login":
					LoginAction(sender, mSender, mContent);
					break;
				case "SignUp":
					SignUpAction(sender, mSender, mContent);
					break;
				case "PrivateMessage":
					PrivateMessageAction(mSender,mContent,mRecipient);
					break;
                case "ViewHistory":
					ViewHistoryAction(sender, mSender, mRecipient);
                    break;
				case "FileTransfer":
					FileTransferAction(mSender, mContent, mRecipient);
					break;
				case "SendFileRequest":
					SendFileRequestAction(mSender, mContent, mRecipient);
					break;
				case "FileRequest":
					FileRequestAction(mSender, mContent, mRecipient);
					break;
				//case "RequestChat":
				//    RequestChat( fullMessage, mRecipient);
				//    break;
				case "CreateNewGroup":
					CreateNewGroup(sender, mSender, mContent);
					break;
				case "AccessGroup":
					AccessGroup(sender, mSender, mContent);
					break;
				case "PrivateMessageGroup":
					PrivateMessageGroupAction(sender, mSender, mContent, mRecipient);
					break;
				case "AddNewMember":
					NewMemberGroup(mSender, mContent, mRecipient);
					break;
				case "QuitGroup":
					QuitGroup(sender, mSender, mContent);
					break;
				case "ViewHistoryGroupChat":
					ViewHistoryGroupChat(sender, mContent, mSender);
					break;
				case "UpdateAvatar":
					UpdateAvatarAction(mSender, mContent, mRecipient, fullMessage);
					break;
				default:
					break;
			}
		}

		//private void UpdateAvatarAction(string sender, string content)
		//{
		//	byte[] byteImage = Convert.FromBase64String(content);
		//	Image newUserAvatar = byteArrayToImage(byteImage);
		//	string receivedPath = System.AppDomain.CurrentDomain.BaseDirectory + "\\avatar\\" + sender.ToLower() + "_avatar.jpeg";
		//	receivedPath = receivedPath.Replace("\\", "/");
		//	newUserAvatar.Save(receivedPath, System.Drawing.Imaging.ImageFormat.jpeg);

		//	Broadcast("UpdateAvatar|" + sender + "|" + content + "|<<AllUsers>>");
		//	AppendText_txtOutgoingMessage("<<AllUsers>>", "UpdateAvatar|" + sender + "|" + content + "|<<AllUsers>>");
		//}

		private void UpdateAvatarAction(string sender, string content, string note, string message)
		{
			if (note.Equals("Init"))
			{
				Avatar newAvatar = new Avatar(sender.ToLower(), Convert.ToInt32(content));
				listAvatar.Add(newAvatar);
			}
			else
			{
				for (int i = 0; i < listAvatar.Count; i++)
				{
					if (listAvatar[i].CheckUsername(sender.ToLower()))
					{
						byte[] byteImage = Convert.FromBase64String(content);
						listAvatar[i].AppendByteImage(byteImage);
					}
					if (note.Equals("LastSegment"))
					{
						Image newUserAvatar = byteArrayToImage(listAvatar[i].GetByteImage());
						string receivedPath = System.AppDomain.CurrentDomain.BaseDirectory + "\\avatar\\" + sender.ToLower() + "_avatar.jpeg";
						receivedPath = receivedPath.Replace("\\", "/");
						newUserAvatar.Save(receivedPath, System.Drawing.Imaging.ImageFormat.Jpeg);
						listAvatar.Remove(listAvatar[i]);
					}
				}
			}
			/*byte[] byteImage = Convert.FromBase64String(content);*/
			//Image newUserAvatar = byteArrayToImage(byteImage);
			//string receivedPath = System.AppDomain.CurrentDomain.BaseDirectory + "\\avatar\\" + sender.ToLower() + ".jpeg";
			//receivedPath = receivedPath.Replace("\\", "/");
			//newUserAvatar.Save(receivedPath, System.Drawing.Imaging.ImageFormat.jpeg);

			Broadcast(message);
			AppendText_txtOutgoingMessage("<<AllUsers>>", message);
		}

		private void ViewHistoryGroupChat(Client sender, string mContent, string mSender)
		{
			List<tblGroupChatHistory> ListHistory = new List<tblGroupChatHistory>();
			ListHistory = serverController.ViewHistoryGroupChat(mContent);
			Invoke(new Action(() => {
				foreach (tblGroupChatHistory item in ListHistory)
				{
					string message = "ViewHistoryGroupChat|" + item.Sender + "|" + item.Time.ToString() + " : " + item.Content + "|" + item.GroupName;
					sender.Send(message);
					AppendText_txtOutgoingMessage(mSender, message);
                    Thread.Sleep(10);
				}

			}));

			AppendText_txtOutgoingMessage(mSender, "ViewHistoryGroupChat|Server|<<" + mSender + "--" + mContent + ">>|" + sender);
		}

		private void QuitGroup(Client sender, string mSender, string mContent)
		{
			Invoke(new Action(() =>
			{
				serverController.DeleteGroupMember(mSender, mContent);
				sender.Send("QuitGroupActive|Server|" + mContent + "|" + mSender);
				Thread.Sleep(100);
				UpdateListMemberToGroup(mContent);
				Thread.Sleep(100);
				UpdateListUserToGroup(mContent);
				Thread.Sleep(100);
				ChangeGroupMember(mSender + " left from group!", mContent);

			}));

		}

		void ChangeGroupMember(string message, string groupName)
		{
			List<string> listMember = serverController.SelectGroupMember(groupName);

			Invoke(new Action(() => {
				for (int j = 0; j < listMember.Count; j++)
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (listMember[j] == item.SubItems[1].Text)
						{
							var client = livActiveUser.Items[i].Tag as Client;
							client.Send("ChangeGroupMember|Server|" + message + "|" + groupName);

						}
					}

				}

			}));
		}

		private void NewMemberGroup(string msender, string groupName, string newMember)
		{
			serverController.InsertGroupMember(newMember, groupName);

			Invoke(new Action(() =>
			{
				for (int i = 0; i < livActiveUser.Items.Count; i++)
				{
					var item = livActiveUser.Items[i];
					if (newMember == item.SubItems[1].Text)
					{
						var client = livActiveUser.Items[i].Tag as Client;
						SendListGroupName(client, newMember);
						break;
					}

				}
				Thread.Sleep(100);
				UpdateListMemberToGroup(groupName);
				Thread.Sleep(100);
				UpdateListUserToGroup(groupName);
				ChangeGroupMember(newMember + " has join on group!", groupName);

			}));

		}

		void UpdateListMemberToGroup(string groupName)
		{
			List<string> listMember = serverController.SelectGroupMember(groupName);
			string content = "";
			foreach (string item in listMember)
				content += item + "/";
			Invoke(new Action(() => {
				for (int j = 0; j < listMember.Count; j++)
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (listMember[j] == item.SubItems[1].Text)
						{
							var client = livActiveUser.Items[i].Tag as Client;
							client.Send("UpdateListMemberToGroup|Server|" + content + "|" + groupName);

						}
					}

				}

			}));

		}

		void UpdateListUserToGroup(string groupName)
		{
			List<string> listMember = serverController.SelectGroupMember(groupName);
			string content = "";
			{
				foreach (ListViewItem itemRow in this.livActiveUser.Items)
				{
					content += itemRow.SubItems[1].Text + "/";
				}
				Invoke(new Action(() => {
					for (int j = 0; j < listMember.Count; j++)
					{
						for (int i = 0; i < livActiveUser.Items.Count; i++)
						{
							var item = livActiveUser.Items[i];
							if (listMember[j] == item.SubItems[1].Text)
							{
								var client = livActiveUser.Items[i].Tag as Client;
								client.Send("UpdateListUserToGroup|Server|" + content + "|" + groupName);

							}
						}

					}
				}));

			}
		}

		private void PrivateMessageGroupAction(Client sender, string mSender, string mContent, string mRecipient)
		{
			List<string> listMember = serverController.SelectGroupMember(mRecipient);
			Invoke(new Action(() =>
			{
				for (int j = 0; j < listMember.Count; j++)
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (listMember[j] == item.SubItems[1].Text && listMember[j] != mSender)
						{
							var client = livActiveUser.Items[i].Tag as Client;
							client.Send("RecivePrivateMessageGroup|" + mSender + "|" + mContent + "|" + mRecipient);
							break;
						}
					}
				}
				serverController.InsertHistoryGroup(mSender, mRecipient, mContent);
			}));

		}

		private void AccessGroup(Client sender, string mSender, string mContent)
		{
			Invoke(new Action(() =>
			{
				// AppendText_txtOutgoingMessage(mSender, "ListUser|Server|SendListUser" + mSender);

				List<string> listmember = serverController.SelectGroupMember(mContent);
				string content = "";
				foreach (string item in listmember)
					content += item + "/";
				sender.Send("ListMember|Sever|" + content + "|" + mContent);
				Thread.Sleep(100);
				SendListUsersToGroupMember(sender, mContent);

			}));

		}

		private void CreateNewGroup(Client sender, string userName, string groupName)
		{
			serverController.InsertGroupName(groupName, userName);
			serverController.InsertGroupMember(userName, groupName);
			SendListGroupName(sender, userName);
		}

		private void FileRequestAction(string sender, string content, string recipient)
		{
			Invoke(new Action(() =>
			{
				try
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (recipient == item.SubItems[1].Text)
						{
							var client = livActiveUser.Items[i].Tag as Client;
							client.Send("FileRequest|" + sender + "|" + content + "|" + recipient);
							break;
						}
					}
					AppendText_txtOutgoingMessage(recipient, "FileRequest|" + sender + "|" + content + "|" + recipient);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
		}

		private void SendFileRequestAction(string sender, string content, string recipient)
		{
			Invoke(new Action(() =>
			{
				try
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (recipient == item.SubItems[1].Text)
						{
							var client = livActiveUser.Items[i].Tag as Client;
							client.Send("SendFileRequest|" + sender + "|" + content + "|" + recipient);
							break;
						}
					}
					AppendText_txtOutgoingMessage(recipient, "SendFileRequest|" + sender + "|" + content + "|" + recipient);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
		}

        private void ResendUsersDisconnect(string mSender)
        {
            Invoke(new Action(()=>
            {
                var message = "Disconnect|" + mSender + "|with|server";
                Broadcast(message);
            }));              
        }

        //private void RequestChat( string fullMessage, string mRecipient)
        //{

        //    Invoke(new Action(() =>
        //    {
        //        for (int i = 0; i < livActiveUser.Items.Count; i++)
        //        {
        //            var item = livActiveUser.Items[i];
        //            if (mRecipient == item.SubItems[1].Text)
        //            {
                       
        //                var client = livActiveUser.Items[i].Tag as Client;
        //                client.Send(fullMessage);                 
        //                  break;
        //            }
        //        }
        //    }));
        //}
		private void FileTransferAction(string sender, string content, string recipient)
		{
			Invoke(new Action(() =>
			{
				try
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (recipient == item.SubItems[1].Text)
						{
							var client = livActiveUser.Items[i].Tag as Client;
							AppendText_txtOutgoingMessage(recipient, "FileTransfer|" + sender + "|" + content + "|" + recipient);
							client.Send("FileTransfer|" + sender + "|" + content + "|" + recipient);
							break;
						}
					}				
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
		}

        private void ViewHistoryAction(Client Sender, string sender, string recipient)
        {
            Invoke(new Action(() =>
            {

                List<tblHistory> ListHistory = new List<tblHistory>();
                ListHistory = serverController.ViewHistory(sender, recipient);
                foreach (tblHistory item in ListHistory)
                {
                    string message = "ViewHistory|" + item.Sender + "|" + item.Time.ToString() + ": " + item.Content + "|" + item.Receipient;
                    Sender.Send("ViewHistory|" + item.Sender + "|" + item.Time.ToString() + ": " + item.Content + "|" + item.Receipient);
                    Thread.Sleep(10);
                    AppendText_txtOutgoingMessage(sender, message);
                }
            }));
			AppendText_txtOutgoingMessage(sender, "ViewHistory|Server|<<" + sender + "--" + recipient + ">>|" + sender);
		}

        private void SignUpAction(Client sender, string username, string password)
		{
			string message;
			string ip = sender.Ip.ToString();
			if (!serverController.IsUsernameExisted(username))
			{
				message = "SignUp|Server|Succeeded|" + sender.Ip.ToString();
				serverController.SignUp(username, password);
				CreateDefaultImage(username);
				sender.Send(message);
				Broadcast("NewUserSignUp|Server|" + username + "|<<AllUsers>>");
			}
			else
			{
				message = "SignUp|Server|Failed|" + sender.Ip.ToString();
				sender.Send(message);
			}
		}

		private void LoginAction(Client sender, string username, string password)
		{
			string message;
			string ip = sender.Ip.ToString();
			if (serverController.CheckLogin(username, password))
			{
				bool isExist = false;
				message = "Login|Server|" + username + "|" + sender.Ip.ToString();
				Invoke(new Action(() =>
				{
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];

						if (username.ToLower().Equals(item.SubItems[1].Text.ToLower()))
						{
							isExist = true;
							message = "Login|Server|<<AlreadyExist>>|" + sender.Ip.ToString();
							break;
						}
						else
						{
							if (ip == item.SubItems[0].Text)
							{
								item.SubItems[1].Text = username;
							}
						}

					}
				}));
				if (!isExist)
				{
					Broadcast("NewActiveUser|Server|" + username + "|<<AllUsers>>");
                    sender.Send(message);
                    AppendText_txtOutgoingMessage("<<AllUsers>>", "NewActiveUser|Server|" + username + "|<<AllUsers>>");
					
                    Thread.Sleep(1000);
                    SendListGroupName(sender, username);
                    Thread.Sleep(100);
                    SendListUsers(sender, username);

				}
				else
				{
					AppendText_txtOutgoingMessage("<<AllUsers>>", message);
					sender.Send(message);
				}
			}
			else
			{
				message = "Login|Server|<<LoginFailed>>|" + sender.Ip.ToString();
				sender.Send(message);
			}
			AppendText_txtOutgoingMessage(ip, message);
		}

		private void PrivateMessageAction(string sender, string content, string recipient)
		{
			Invoke(new Action(() =>
			{
				try
				{
					//string ipRecipent= "";
					for (int i = 0; i < livActiveUser.Items.Count; i++)
					{
						var item = livActiveUser.Items[i];
						if (recipient == item.SubItems[1].Text)
						{
							// ipRecipent = item.SubItems[0].Text;
							var client = livActiveUser.Items[i].Tag as Client;
							client.Send("PrivateMessage|" + sender + "|" + content + "|" + recipient);
							serverController.InsertHistory(sender, content, recipient, System.DateTime.Now);
							break;
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
			      
		}

		private void AppendText_txtConnectMessage(string recipient, string message)
		{
			Invoke(new Action(() => txtConnectMessage.SelectionColor = System.Drawing.Color.Red));
			Invoke(new Action(() => txtConnectMessage.AppendText(System.DateTime.Now + ":\n")));
			Invoke(new Action(() => txtConnectMessage.SelectionColor = System.Drawing.Color.Black));
			Invoke(new Action(() => txtConnectMessage.AppendText(message)));
			Invoke(new Action(() => txtConnectMessage.AppendText(Environment.NewLine + Environment.NewLine)));
		}

		private void AppendText_txtIncomingMessage(string recipient, string message)
		{
			Invoke(new Action(() => txtIncomingMessage.SelectionColor = System.Drawing.Color.Red));
			Invoke(new Action(() => txtIncomingMessage.AppendText(System.DateTime.Now + ":\nFrom " + recipient + ":\n")));
			Invoke(new Action(() => txtIncomingMessage.SelectionColor = System.Drawing.Color.Black));
			Invoke(new Action(() => txtIncomingMessage.AppendText(message)));
			Invoke(new Action(() => txtIncomingMessage.AppendText(Environment.NewLine + Environment.NewLine)));
		}

		private void AppendText_txtOutgoingMessage(string recipient, string message)
		{
			Invoke(new Action(() => txtOutgoingMessage.SelectionColor = System.Drawing.Color.Red));
			Invoke(new Action(() => txtOutgoingMessage.AppendText(System.DateTime.Now + ":\nTo " + recipient + ":\n")));
			Invoke(new Action(() => txtOutgoingMessage.SelectionColor = System.Drawing.Color.Black));
			Invoke(new Action(() => txtOutgoingMessage.AppendText(message)));
			Invoke(new Action(() => txtOutgoingMessage.AppendText(Environment.NewLine + Environment.NewLine)));
		}

		private void Server_Load(object sender, EventArgs e)
		{
			listener.Start();
			txtConnectMessage.AppendText(System.DateTime.Now + ":\nServer started on " + serverIP + " !\n\n");
		}

		private void livActiveUser_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void SendListUsers(Client sender, string recipient)
		{
			string mContent = "";
			Invoke(new Action(() =>
			{
				foreach (ListViewItem itemRow in this.livActiveUser.Items)
				{
					mContent += itemRow.SubItems[1].Text + "/";
				}
			}));
			mContent += "<<null>>";
			
			string message = "ListUsers|Server|" + mContent + "|" + recipient;
			sender.Send(message);
			AppendText_txtOutgoingMessage(recipient, message);
		}

		private void SendListUsersToGroupMember(Client sender, string groupname)
		{
			string mContent = "";
			Invoke(new Action(() =>
			{
				foreach (ListViewItem itemRow in this.livActiveUser.Items)
				{
					mContent += itemRow.SubItems[1].Text + "/";
				}
			}));
			mContent += "<<null>>";

			string message = "ListUsersToGroup|Server|" + mContent + "|" + groupname;
			sender.Send(message);
			AppendText_txtOutgoingMessage(groupname, message);
		}

		private void SendListGroupName(Client sender, string username)
		{
			List<string> listNameGroup = serverController.SelectGroupName(username);
			string content = "";
			Invoke(new Action(() =>
			{
				foreach (string item in listNameGroup)
				{
					if (item != "")
					{
						content += item + "/";
					}

				}
				sender.Send("ListGroupName|Server|" + content + "|" + username);
			}));


		}

		private void Broadcast(string message)
		{
			for (int i = 0; i < clients.Count; i++)
			{
				try
				{
					clients[i].Send(Encoding.ASCII.GetBytes(message));
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}
		}

		public Image byteArrayToImage(byte[] byteArrayIn)
		{
			MemoryStream ms = new MemoryStream(byteArrayIn);
			Image returnImage = Image.FromStream(ms);
			return returnImage;
		}

		protected void CreateDefaultImage(string username)
		{
			string sourceFile = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\default_avatar.jpeg";
			sourceFile = sourceFile.Replace("\\", "/");
			string destFile = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\" + username.ToLower() + "_avatar.jpeg";
			destFile = destFile.Replace("\\", "/");
			System.IO.File.Copy(sourceFile, destFile);
		}

		//private void StartServer()
		//{
		//	try
		//	{
		//		IPAddress IP = IPAddress.Parse("127.0.0.1");
		//		listener = new TcpListener(IP, PORT_NUMBER);
		//		listener.Start();

		//		richtxtServer.AppendText("Server started on " + listener.LocalEndpoint + "\n");
		//		richtxtServer.AppendText("Wait for client connection....!\n");

		//		for (int i = 0; i < 5; i++)
		//		{			
		//			Thread t = new Thread(new ThreadStart(Service));
		//			t.Start();
		//		}
		//	}
		//	catch (Exception ex)
		//	{
		//		MessageBox.Show("Error " + ex.Message);
		//	}
		//}

		//public void Service(){


		//	while (true){
		//		Socket socket = listener.AcceptSocket();
		//		socket.SetSocketOption(SocketOptionLevel.Socket,
		//				SocketOptionName.ReceiveTimeout, 10000);
		//		//soc.SetSocketOption(SocketOptionLevel.Socket,
		//		//        SocketOptionName.ReceiveTimeout,10000);
		//		//richtxtServer.AppendText("A client connect to Server on " + socket.RemoteEndPoint + "\n");
		//		Invoke(new Action(() => richtxtServer.AppendText("A client connect to Server on " + socket.RemoteEndPoint + "\n")));
		//		try
		//		{
		//			byte[] data = new byte[BUFFER_SIZE];
		//			socket.Receive(data);
		//			var message = Encoding.ASCII.GetString(data).Split('|');
		//			string fullMessage = Encoding.ASCII.GetString(data);
		//			Invoke(new Action(() => richtxtServer.AppendText(fullMessage)));
		//			Invoke(new Action(() => richtxtServer.AppendText(Environment.NewLine)));

		//		}
		//		catch(Exception e){
		//		}
		//		socket.Close();
		//	}
		//}

		//private void button1_Click(object sender, EventArgs e)
		//      {
		//          StartServer();
		//      }
	}
}
