﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatAppClient
{
    public partial class GroupChat : Form
    {
         public string groupName;
        public User userForm;
        ClientSocket Client;
        private Label lbGroupName;
        private Button btnAdd;
        private Button btnQuit;
        private Button btnHistory;
        private ListView livMember;
        private ListView livActiveUser;
        private Button btnSend;
        private RichTextBox txtInputMessage;
        private RichTextBox rtxtContentChatGroup;
        public string userName;

        public GroupChat( User _userForm,string _nameGroup, string _userName,string sender, string firstMessage)
        {
            InitializeComponent();
            userForm = _userForm;
            groupName = _nameGroup;
            userName = _userName;
            lbGroupName.Text = groupName;
            Client = userForm._loginForm.Client;
            userForm._loginForm.Client.Received += Client_Received;
            if (firstMessage != "<<Null>>")
            {
              
                rtxtContentChatGroup.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
                rtxtContentChatGroup.SelectionIndent = 0;
                rtxtContentChatGroup.SelectionRightIndent = rtxtContentChatGroup.Width / 2 - 5;
                rtxtContentChatGroup.SelectionColor = System.Drawing.Color.Teal;
                rtxtContentChatGroup.AppendText(sender + ": " + firstMessage + Environment.NewLine);
            }

        }
      
        private void Client_Received(ClientSocket cs, string received)
        {
            var message = received.Split('|');
            string mType = message[0];
            string mSender = message[1];
            string mContent = message[2];
            string mRecipient = message[3];
            switch (mType)
            {
                   
                case "ListUsersToGroup":
                    ListUsersAction(mContent, mRecipient);
                    break;
                case "RecivePrivateMessageGroup":
                    RecivePrivateMessageGroup(mSender, mContent, mRecipient);
                    break;
                case "ListMember":
                    ListMember(mContent, mRecipient);
                    break;
                case "UpdateListMemberToGroup":
                    ListMember(mContent,mRecipient);            
                    break;
                case "UpdateListUserToGroup":
                    ListUsersAction(mContent, mRecipient);
                    break;
                case "ChangeGroupMember":
                    ChangeGroupMember(mContent, mRecipient);
                    break;
                default:
                    break;
            }
        }

        private void ChangeGroupMember(string mContent, string mRecipient)
        {
            if(this.IsHandleCreated)
            {
                Invoke(new Action(() =>
                {
                    if (lbGroupName.Text == mRecipient)
                    {


                        rtxtContentChatGroup.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Center;
                        rtxtContentChatGroup.SelectionColor = System.Drawing.Color.Red;
                        rtxtContentChatGroup.AppendText( mContent + Environment.NewLine);
                    }

                }));
            }
         
        }

        private void ListMember(string mContent, string _groupName)
        {
            if(this.IsHandleCreated)
            {

                var listMember = mContent.Split('/');

                Invoke(new Action(() =>
                {
                    if(groupName==_groupName)
                    {
                        while (livMember.Items.Count > 0)
                        {
                            for (int i = 0; i < livMember.Items.Count; i++)
                            {
                                livMember.Items.RemoveAt(i);

                            }
                        }
                        for (int i = 0; i < listMember.Length; i++)
                        {

                            if (listMember[i] != "")
                            {
                                var item = new ListViewItem(listMember[i]);
                                livMember.Items.Add(item);
                            }

                        }
                    }
                 
                }));

            }
        }

        private void RecivePrivateMessageGroup(string mSender, string mContent, string mRecipient)
        {
            if(this.IsHandleCreated)
            {
                Invoke(new Action(() =>
                {
                    if(lbGroupName.Text==mRecipient)
                    {
                        //rtxtContentChatGroup.AppendText(mSender + ": " + mContent);
                        //rtxtContentChatGroup.AppendText(Environment.NewLine);

                        rtxtContentChatGroup.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
                        rtxtContentChatGroup.SelectionIndent = 0;
                        rtxtContentChatGroup.SelectionRightIndent = rtxtContentChatGroup.Width / 2 - 5;
                        rtxtContentChatGroup.SelectionColor = System.Drawing.Color.Teal;
                        rtxtContentChatGroup.AppendText(mSender + ": " + mContent + Environment.NewLine);
                    }
                   
                }));
            }
           
        }

        private void ListUsersAction(string content, string _groupname)
        {
            if (this.IsHandleCreated)
            {
               
                var listUsers = content.Split('/');
                this.Invoke(new Action(() =>
                {
                    if (_groupname == groupName)
                    {
                        while(livActiveUser.Items.Count>0)
                        {
                            for (int i = 0; i < livActiveUser.Items.Count; i++)
                                livActiveUser.Items.RemoveAt(i);
                        }
                     
                      for (int i = 0; i < listUsers.Length; i++)
                        {
                            bool check = true;

                            for (int j = 0; j < livMember.Items.Count; j++)
                            {
                                if (listUsers[i] == livMember.Items[j].Text)
                                {
                                    check = false;
                                    break;
                                }
                            }
                            if (check)
                            {
                                if (listUsers[i] != "<<undefined>>" && listUsers[i] != "<<null>>")
                                {
                                    var item = new ListViewItem(listUsers[i]);
                                    livActiveUser.Items.Add(item);
                                }
                            }

                        }
                    }
                   
                }));
            }
        }

	

		private void InitializeComponent()
		{
            this.lbGroupName = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnHistory = new System.Windows.Forms.Button();
            this.livMember = new System.Windows.Forms.ListView();
            this.livActiveUser = new System.Windows.Forms.ListView();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtInputMessage = new System.Windows.Forms.RichTextBox();
            this.rtxtContentChatGroup = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lbGroupName
            // 
            this.lbGroupName.AutoSize = true;
            this.lbGroupName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGroupName.ForeColor = System.Drawing.Color.White;
            this.lbGroupName.Location = new System.Drawing.Point(460, 20);
            this.lbGroupName.Name = "lbGroupName";
            this.lbGroupName.Size = new System.Drawing.Size(60, 24);
            this.lbGroupName.TabIndex = 24;
            this.lbGroupName.Text = "label1";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.MintCream;
            this.btnAdd.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnAdd.Location = new System.Drawing.Point(447, 164);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(74, 37);
            this.btnAdd.TabIndex = 23;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.Color.MintCream;
            this.btnQuit.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnQuit.Location = new System.Drawing.Point(11, 277);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(88, 37);
            this.btnQuit.TabIndex = 21;
            this.btnQuit.Text = "QUIT";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnHistory
            // 
            this.btnHistory.BackColor = System.Drawing.Color.MintCream;
            this.btnHistory.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnHistory.Location = new System.Drawing.Point(328, 277);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(89, 37);
            this.btnHistory.TabIndex = 22;
            this.btnHistory.Text = "HISTORY";
            this.btnHistory.UseVisualStyleBackColor = false;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // livMember
            // 
            this.livMember.Location = new System.Drawing.Point(425, 221);
            this.livMember.Name = "livMember";
            this.livMember.Size = new System.Drawing.Size(126, 95);
            this.livMember.TabIndex = 19;
            this.livMember.UseCompatibleStateImageBehavior = false;
            this.livMember.View = System.Windows.Forms.View.List;
            // 
            // livActiveUser
            // 
            this.livActiveUser.Location = new System.Drawing.Point(425, 56);
            this.livActiveUser.Name = "livActiveUser";
            this.livActiveUser.Size = new System.Drawing.Size(126, 103);
            this.livActiveUser.TabIndex = 20;
            this.livActiveUser.UseCompatibleStateImageBehavior = false;
            this.livActiveUser.View = System.Windows.Forms.View.List;
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSend.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnSend.Location = new System.Drawing.Point(434, 323);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(100, 49);
            this.btnSend.TabIndex = 18;
            this.btnSend.Text = "SEND";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtInputMessage
            // 
            this.txtInputMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInputMessage.Location = new System.Drawing.Point(11, 323);
            this.txtInputMessage.Name = "txtInputMessage";
            this.txtInputMessage.Size = new System.Drawing.Size(406, 49);
            this.txtInputMessage.TabIndex = 17;
            this.txtInputMessage.Text = "";
            // 
            // rtxtContentChatGroup
            // 
            this.rtxtContentChatGroup.BackColor = System.Drawing.Color.White;
            this.rtxtContentChatGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtContentChatGroup.Location = new System.Drawing.Point(11, 21);
            this.rtxtContentChatGroup.Name = "rtxtContentChatGroup";
            this.rtxtContentChatGroup.ReadOnly = true;
            this.rtxtContentChatGroup.Size = new System.Drawing.Size(406, 250);
            this.rtxtContentChatGroup.TabIndex = 16;
            this.rtxtContentChatGroup.Text = "";
            // 
            // GroupChat
            // 
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(563, 387);
            this.Controls.Add(this.lbGroupName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnHistory);
            this.Controls.Add(this.livMember);
            this.Controls.Add(this.livActiveUser);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txtInputMessage);
            this.Controls.Add(this.rtxtContentChatGroup);
            this.MaximizeBox = false;
            this.Name = "GroupChat";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GroupChat_FormClosing);
            this.Load += new System.EventHandler(this.GroupChat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {
                try
                {
                    //var item = new ListViewItem(livActiveUser.SelectedItems[0].Text);
                    string member = livActiveUser.SelectedItems[0].Text;
                    //livMember.Items.Add(item);
                    Client.Send("AddNewMember|" + userName + "|" + groupName + "|" + member);
                    //livActiveUser.Items.RemoveAt(livActiveUser.SelectedItems[0].Index);
                }
                catch
                {
                    MessageBox.Show("You have not selected member!");
                }


            }));
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (txtInputMessage.Text == "")
            {
                MessageBox.Show("Empty Message!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Client.Send("PrivateMessageGroup|" + userName + "|" + txtInputMessage.Text + "|" + lbGroupName.Text);
                rtxtContentChatGroup.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Right;
                rtxtContentChatGroup.SelectionIndent = rtxtContentChatGroup.Width / 2 + 5;
                rtxtContentChatGroup.SelectionRightIndent = 0;
                rtxtContentChatGroup.AppendText(txtInputMessage.Text + Environment.NewLine);
                txtInputMessage.Text = "";
              
                //rtxtContentChatGroup.AppendText("You: " + txtInputMessage.Text);
                //rtxtContentChatGroup.AppendText(Environment.NewLine);
                //txtInputMessage.Text = "";
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Client.Send("QuitGroup|" + userName + "|" + groupName + "|Server");
            userForm.listGroupChat.Remove(this);
            this.Close();
        }

        private void GroupChat_Load(object sender, EventArgs e)
        {
            Client.Send("AccessGroup|" + userName + "|" + groupName + "|server");
            txtInputMessage.Focus();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            HistoryGroupChat history = new HistoryGroupChat(this, groupName);
            history.Show();
        }

       

        private void GroupChat_FormClosing(object sender, FormClosingEventArgs e)
        {
            userForm.listGroupChat.Remove(this);
        }
    }
}
