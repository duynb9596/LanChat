﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace ChatAppClient
{
    public partial class HistoryChat : Form
    {
        PrivateChat _privateChatForm;
        string _target;
        string _UserName;
        ClientSocket client;
        
        public HistoryChat( PrivateChat privateChatForm,string username, string target)
        {
            _privateChatForm = privateChatForm;
            _target = target;
            _UserName = username;         
            client = _privateChatForm._userForm._loginForm.Client;
            client.Received += Client_Received;
            InitializeComponent();
        }

        private void Client_Received(ClientSocket cs, string received)
        {
			//var message = received.Split('|');   
			//int i = 2;
			//if(message[0]== "ViewHistory")
			//{
			//    Invoke(new Action(() =>       
			//    {
			//        Invoke(new Action(() => txtHistory.AppendText(message[i])));
			//        Invoke(new Action(() => txtHistory.AppendText(Environment.NewLine+ Environment.NewLine)));
			//    } ));

			//    do
			//    {
			//        if(message[i-1]== _target)
			//        {
			//            Invoke(new Action(() => txtHistory.AppendText(message[i])));
			//            Invoke(new Action(() => txtHistory.AppendText(Environment.NewLine+ Environment.NewLine)));
			//        }
			//        else
			//        {
			//            Invoke(new Action(() => txtHistory.AppendText("\t\t\t\t "+message[i])));
			//            Invoke(new Action(() => txtHistory.AppendText(Environment.NewLine + Environment.NewLine)));
			//        }

			//        i += 4;
			//    } while (i < message.Length);

			//}
			var message = received.Split('|');
			string mType = message[0];
			string mSender = message[1];
			string mContent = message[2];
			string mRecipient = message[3];
			switch (mType)
			{
				case "ViewHistory":
					ViewHistoryAction(mContent, mSender);
					break;
				default:
					break;
			}

		}

		private void ViewHistoryAction(string content, string sender)
		{
            if (this.IsHandleCreated)
            {
                Invoke(new Action(() =>
                {
                    if (sender == _target)
                    {
                        txtHistory.SelectionIndent = 0;
                        txtHistory.SelectionRightIndent = txtHistory.Width / 2 - 5;
                        txtHistory.SelectionColor = System.Drawing.Color.Magenta;
                        txtHistory.AppendText(content);
                        txtHistory.AppendText(Environment.NewLine + Environment.NewLine);
                    }
                    else
                    {
                        txtHistory.SelectionIndent = txtHistory.Width / 2 + 5;
                        txtHistory.SelectionRightIndent = 0;
                        txtHistory.SelectionColor = System.Drawing.Color.Teal;
                        txtHistory.AppendText(content);
                        txtHistory.AppendText(Environment.NewLine + Environment.NewLine);
                    }
                }));
            }
		}

		private void HistoryChat_Load(object sender, EventArgs e)
        {
            lbChatWith.Text = _target;
            client.Send("ViewHistory|" + _UserName + "|" + "HistoryChat|" + _target);
        }  
    }
}
