﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatAppClient
{
	public partial class User : Form
	{
		public Login _loginForm;

		public List<PrivateChat> listPrivateChat = new List<PrivateChat>();
		public List<GroupChat> listGroupChat = new List<GroupChat>();
		public ClientSocket Client;
		List<Avatar> listAvatar;

		public User(Login loginForm, string username)
		{
			_loginForm = loginForm;
			_loginForm.Client.Received += client_Received;
			InitializeComponent();
			Client = _loginForm.Client;
			ChangeLabelUsername(username);
			listAvatar = new List<Avatar>();

			string avatar = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\" + lblUsername.Text.ToLower() + "_avatar.jpeg";
			avatar = avatar.Replace("\\", "/");
			if (File.Exists(avatar))
				LoadAvatar();
			else
			{
				CreateDefaultImage(username);
				LoadAvatar();
			}		
		}

		public void client_Received(ClientSocket cs, string received)
		{
			var message = received.Split('|');
			string mType = message[0];
			string mSender = message[1];
			string mContent = message[2];
			string mRecipient = message[3];
			switch (mType)
			{
				case "NewActiveUser":
					NewActiveUserAction(mContent);
					break;
				case "ListUsers":
					ListUsersAction(mContent);
					break;
				case "PrivateMessage":
					PrivateMessageAction(mSender, mRecipient, mContent);
					break;
				case "Disconnect":
					UpdateListUsers(mSender);
					break;
				//case "FileTransfer":
				//	FileTransferAction(mSender, mRecipient, mContent);
				//	break;
				case "SendFileRequest":
					SendFileRequestAction(mSender, mRecipient, mContent);
					break;
				case "ListGroupName":
					ListNameGroup(mContent);
					break;
				case "RecivePrivateMessageGroup":
					RecivePrivateMessageGroup(mSender, mContent, mRecipient);
					break;
				case "QuitGroupActive":
					QuitGroupActive(mContent);
					break;
				case "UpdateAvatar":
					UpdateAvatarAction(mSender, mContent, mRecipient);
					break;
				case "NewUserSignUp":
					NewUserSignUpAction(mContent);
					break;
				default:
					break;
			}
		}

		private void NewUserSignUpAction(string content)
		{
			CreateDefaultImage(content);
		}

		private void UpdateAvatarAction(string sender, string content, string note)
		{
			if (note.Equals("Init"))
			{
				Avatar newAvatar = new Avatar(sender.ToLower(), Convert.ToInt32(content));
				listAvatar.Add(newAvatar);
			}
			else
			{
				for (int i = 0; i < listAvatar.Count; i++)
				{
					if (listAvatar[i].CheckUsername(sender.ToLower()))
					{
						byte[] byteImage = Convert.FromBase64String(content);
						listAvatar[i].AppendByteImage(byteImage);
					}
					if (note.Equals("LastSegment"))
					{
						Image newUserAvatar = byteArrayToImage(listAvatar[i].GetByteImage());
						string receivedPath = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\" + sender.ToLower() + "_avatar.jpeg";
						receivedPath = receivedPath.Replace("\\", "/");
						newUserAvatar.Save(receivedPath, System.Drawing.Imaging.ImageFormat.Jpeg);
						listAvatar.Remove(listAvatar[i]);
						LoadAvatar();
					}
				}
			}
		}

		private void QuitGroupActive(string mContent)
		{
			Invoke(new Action(() =>
			{
				for (int i = 0; i < livListGroup.Items.Count; i++)
				{
					if (livListGroup.Items[i].Text == mContent)
					{
						livListGroup.Items.RemoveAt(i);
						break;
					}

				}

			}));
		}

		private void InviteToGroup(string mContent)
		{
			Invoke(new Action(() =>
			{
				var item = new ListViewItem(mContent);
				livListGroup.Items.Add(item);

			}));
		}

		private void RecivePrivateMessageGroup(string mSender, string mContent, string mRecipient)
		{
			Invoke(new Action(() =>
			{
				bool isTargetExist = false;
				for (int i = 0; i < listGroupChat.Count; i++)
				{
					if (listGroupChat[i].groupName == mRecipient)
					{
						isTargetExist = true;
						break;
					}
				}
				if (!isTargetExist)
				{
					GroupChat GroupChat = new GroupChat(this, mRecipient, lblUsername.Text, mSender, mContent);
					listGroupChat.Add(GroupChat);
					GroupChat.Show();

				}
			}));
		}

		private void ListNameGroup(string mContent)
		{

			Invoke(new Action(() =>
			{
				var listNameGroup = mContent.Split('/');
				while (livListGroup.Items.Count > 0)
				{
					for (int j = 0; j < livListGroup.Items.Count; j++)
						livListGroup.Items.RemoveAt(j);
				}

				for (int i = 0; i < listNameGroup.Length; i++)
				{
					if (listNameGroup[i] != "")
					{
						var item = new ListViewItem(listNameGroup[i]);
						livListGroup.Items.Add(item);
					}
				}

			}));

		}

		private void SendFileRequestAction(string sender, string recipient, string content)
		{
			Invoke(new Action(() =>
			{
				try
				{
					bool isTargetExist = false;
					for (int i = 0; i < listPrivateChat.Count; i++)
					{
						if (listPrivateChat[i]._target == sender)
						{
							isTargetExist = true;
							break;
						}
					}
					if (!isTargetExist)
					{
						PrivateChat privateChat = new PrivateChat(this, lblUsername.Text, sender, "File request name: \"" + content + "\"");
						listPrivateChat.Add(privateChat);
						privateChat.Show();
						privateChat.SendFileRequestAction(sender, lblUsername.Text, content);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
		}

		//private void FileTransferAction(string sender, string recipient, string content)
		//{
		//	Invoke(new Action(() =>
		//	{
		//		try
		//		{
		//			string receivedPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\";
		//			//string receivedPath = AppDomain.CurrentDomain.BaseDirectory + "FileTransfer\\";
		//			receivedPath = receivedPath.Replace("\\", "/");
		//			byte[] clientData = Encoding.ASCII.GetBytes(content);
		//			int receivedBytesLen = clientData.Length;
		//			int fileNameLen = BitConverter.ToInt32(clientData, 0);
		//			string fileName = Encoding.ASCII.GetString(clientData, 4, fileNameLen);
		//			BinaryWriter bWrite = new BinaryWriter(File.Open(receivedPath + fileName, FileMode.Append));

		//			bWrite.Write(clientData, 4 + fileNameLen, receivedBytesLen - 4 - fileNameLen);
		//			bWrite.Close();
		//		}
		//		catch(Exception ex)
		//		{
		//			MessageBox.Show(ex.ToString());
		//		}			
		//	}));
		//}

		private void UpdateListUsers(string mSender)
		{
			Invoke(new Action(() =>
			{
				for (int i = 0; i < livUsers.Items.Count; i++)
				{

					if (livUsers.Items[i].SubItems[0].Text == mSender)
					{
						livUsers.Items[i].Remove();
						break;
					}
				}

			}));
		}

		private void PrivateMessageAction(string mSender, string mRecipient, string mContent)
		{
			Invoke(new Action(() =>
			{
				bool isTargetExist = false;
				for (int i = 0; i < listPrivateChat.Count; i++)
				{
					if (listPrivateChat[i]._target == mSender)
					{
						isTargetExist = true;
						break;
					}
				}
				if (!isTargetExist)
				{
					PrivateChat privateChat = new PrivateChat(this, lblUsername.Text, mSender, mContent);
					listPrivateChat.Add(privateChat);
					privateChat.Show();
				}
			}));
		}

		private void NewActiveUserAction(string username)
		{
			this.Invoke(new Action(() =>
			{
				bool isExist = false;
				for (int i = 0; i < livUsers.Items.Count; i++)
				{
					if (livUsers.Items[i].ToString() == username)
					{
						isExist = true;
						break;
					}
				}
				if (!isExist)
				{
					var item = new ListViewItem(username); // ip
					livUsers.Items.Add(item);
				}
			}));
		}

		private void ListUsersAction(string data)
		{
			var listUsers = data.Split('/');
			this.Invoke(new Action(() =>
			{
				for (int i = 0; i < listUsers.Length; i++)
				{
					if (listUsers[i] != "<<undefined>>" && listUsers[i] != lblUsername.Text && listUsers[i] != "<<null>>")
					{
						var item = new ListViewItem(listUsers[i]);
						livUsers.Items.Add(item);
					}
				}
			}));
		}

		public void ChangeLabelUsername(string name)
		{
			lblUsername.Text = name;
		}

		private void User_FormClosed(object sender, FormClosedEventArgs e)
		{
			Client.Send("Disconnect|" + lblUsername.Text + "|<<Disconnect>>|Server");
			_loginForm.Close();
		}

		private void livUsers_DoubleClick(object sender, EventArgs e)
		{
			bool isTargetExist = false;
			for (int i = 0; i < listPrivateChat.Count; i++)
			{
				if (listPrivateChat[i]._target == livUsers.SelectedItems[0].Text.ToString())
				{
					isTargetExist = true;
					listPrivateChat[i].Show();
					break;
				}
			}
			if (!isTargetExist)
			{
				string targetAvatar = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\" + livUsers.SelectedItems[0].Text.ToLower() + "_avatar.jpeg";
				targetAvatar = targetAvatar.Replace("\\", "/");
				if (File.Exists(targetAvatar))
				{
					PrivateChat privateChat = new PrivateChat(this, lblUsername.Text, livUsers.SelectedItems[0].Text.ToString(), "<<null>>");
					listPrivateChat.Add(privateChat);
					privateChat.Show();
				}
				else
				{
					CreateDefaultImage(livUsers.SelectedItems[0].Text.ToString());
				}
			}
		}

		private void livListGroup_DoubleClick(object sender, EventArgs e)
		{
            try
            {
                Invoke(new Action(() =>
                {
                    bool isTargetExist = false;
                    for (int i = 0; i < listGroupChat.Count; i++)
                    {
                        if (listGroupChat[i].groupName == livListGroup.SelectedItems[0].Text.ToString())
                        {
                            isTargetExist = true;
                            listGroupChat[i].Show();
                            break;
                        }
                    }
                    if (!isTargetExist)
                    {
                        GroupChat groupChat = new GroupChat(this, livListGroup.SelectedItems[0].Text, lblUsername.Text, "undefine", "<<Null>>");
                        listGroupChat.Add(groupChat);
                        groupChat.Show();

                    }
                }));
            }
            catch(Exception n)
            {
                MessageBox.Show(n.ToString());
            }
			
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			Invoke(new Action(() =>
			{
				if (txtCreateNameGroup.Text == "")
				{
					MessageBox.Show("You have no group name!");
				}
				else
				{
					Client.Send("CreateNewGroup|" + lblUsername.Text + "|" + txtCreateNameGroup.Text + "|Server");
					txtCreateNameGroup.Text = "";
				}

			}));
		}

		public Bitmap ResizeImage(Image image, int width, int height)
		{
			var destRect = new Rectangle(0, 0, width, height);
			var destImage = new Bitmap(width, height);

			destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

			using (var graphics = Graphics.FromImage(destImage))
			{
				graphics.CompositingMode = CompositingMode.SourceCopy;
				graphics.CompositingQuality = CompositingQuality.HighQuality;
				graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
				graphics.SmoothingMode = SmoothingMode.HighQuality;
				graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

				using (var wrapMode = new ImageAttributes())
				{
					wrapMode.SetWrapMode(WrapMode.TileFlipXY);
					graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
				}
			}

			return destImage;
		}

		public static byte[] ImageToByteArray(Image x)
		{
			ImageConverter _imageConverter = new ImageConverter();
			byte[] xByte = (byte[])_imageConverter.ConvertTo(x, typeof(byte[]));
			return xByte;
		}

		//private void picAvatar_DoubleClick(object sender, EventArgs e)
		//{
		//	OpenFileDialog dlg = new OpenFileDialog();
		//	dlg.Title = "Open Image";
		//	dlg.Filter = "Image files (*.jpg, *.jpeg, *.bmp, *.jpeg) | *.jpg; *.jpeg; .*bmp; *.jpeg";
		//	if (dlg.ShowDialog() == DialogResult.OK)
		//	{
		//		Image newAvatar = Image.FromFile(dlg.FileName);
		//		newAvatar = ResizeImage(newAvatar, 60, 60);
		//		byte[] byteImage = ImageToByteArray(newAvatar);
		//		Client.Send("UpdateAvatar|" + lblUsername.Text + "|" + Convert.ToBase64String(byteImage) + "|All");
		//	}
		//}

		const int bytePerSend = 10000;			//default should be 10000
		const int sleepTimePerSend = 500;		//default should be 1000
		const int imageWidthAndHeight = 200;    //default should be 200

		public Image byteArrayToImage(byte[] byteArrayIn)
		{
			MemoryStream ms = new MemoryStream(byteArrayIn);
			Image returnImage = Image.FromStream(ms);
			return returnImage;
		}

		private void picAvatar_DoubleClick(object sender, EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Title = "Open Image";
			dlg.Filter = "Image files (*.jpg, *.jpeg, *.bmp, *.png) | *.jpg; *.jpeg; .*bmp; *.png";
			if (dlg.ShowDialog() == DialogResult.OK)
			{
				Image newAvatar = Image.FromFile(dlg.FileName);
				if (newAvatar.Width > imageWidthAndHeight && newAvatar.Height > imageWidthAndHeight)
				{
					newAvatar = ResizeImage(newAvatar, imageWidthAndHeight, imageWidthAndHeight);
				}
				else
				{
					if (newAvatar.Width > newAvatar.Height)
					{
						newAvatar = ResizeImage(newAvatar, newAvatar.Height, newAvatar.Height);
					}
					else
					{
						newAvatar = ResizeImage(newAvatar, newAvatar.Width, newAvatar.Width);
					}
				}

				byte[] byteImage = ImageToByteArray(newAvatar);

				Client.Send("UpdateAvatar|" + lblUsername.Text + "|" + byteImage.Length + "|Init");

				int offset = 0;
				int count = 1;
				while (offset + bytePerSend < byteImage.Length)
				{
					byte[] segment = new byte[bytePerSend];
					Array.Copy(byteImage, offset, segment, 0, bytePerSend);
					Thread.Sleep(sleepTimePerSend);
					string message = "UpdateAvatar|" + lblUsername.Text + "|" + Convert.ToBase64String(segment) + "|Segment";
					Client.Send(message);
					count++;
					offset += bytePerSend;
				}

				int lastSegmentLength = byteImage.Length - offset;
				byte[] lastSegment = new byte[lastSegmentLength];
				Array.Copy(byteImage, offset, lastSegment, 0, lastSegmentLength);
				Thread.Sleep(sleepTimePerSend);
				Client.Send("UpdateAvatar|" + lblUsername.Text + "|" + Convert.ToBase64String(lastSegment) + "|LastSegment");
			}
		}

		protected void LoadAvatar()
		{
			string avatar_path = @"Avatar\" + lblUsername.Text.ToLower() + "_avatar.jpeg";
			picAvatar.Image = ResizeImage(Image.FromFile(avatar_path), picAvatar.Width, picAvatar.Height);
		}

		protected void CreateDefaultImage(string username)
		{
			string sourceFile = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\default_avatar.jpeg";
			sourceFile = sourceFile.Replace("\\", "/");
			string destFile = System.AppDomain.CurrentDomain.BaseDirectory + "avatar\\" + username.ToLower() + "_avatar.jpeg";
			destFile = destFile.Replace("\\", "/");
			System.IO.File.Copy(sourceFile, destFile);
		}
	}
}
