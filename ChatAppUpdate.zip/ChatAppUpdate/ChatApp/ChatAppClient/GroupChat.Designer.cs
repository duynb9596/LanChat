﻿namespace ChatAppClient
{
    partial class GroupChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtContentChatGroup = new System.Windows.Forms.RichTextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtInputMessage = new System.Windows.Forms.RichTextBox();
            this.livActiveUser = new System.Windows.Forms.ListView();
            this.livMember = new System.Windows.Forms.ListView();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnHistory = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lbGroupName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtxtContentChatGroup
            // 
            this.rtxtContentChatGroup.BackColor = System.Drawing.Color.White;
            this.rtxtContentChatGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxtContentChatGroup.Location = new System.Drawing.Point(12, 10);
            this.rtxtContentChatGroup.Name = "rtxtContentChatGroup";
            this.rtxtContentChatGroup.ReadOnly = true;
            this.rtxtContentChatGroup.Size = new System.Drawing.Size(406, 250);
            this.rtxtContentChatGroup.TabIndex = 8;
            this.rtxtContentChatGroup.Text = "";
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSend.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnSend.Location = new System.Drawing.Point(435, 312);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(100, 49);
            this.btnSend.TabIndex = 10;
            this.btnSend.Text = "SEND";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtInputMessage
            // 
            this.txtInputMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInputMessage.Location = new System.Drawing.Point(12, 312);
            this.txtInputMessage.Name = "txtInputMessage";
            this.txtInputMessage.Size = new System.Drawing.Size(406, 49);
            this.txtInputMessage.TabIndex = 9;
            this.txtInputMessage.Text = "";
            // 
            // livActiveUser
            // 
            this.livActiveUser.Location = new System.Drawing.Point(426, 45);
            this.livActiveUser.Name = "livActiveUser";
            this.livActiveUser.Size = new System.Drawing.Size(126, 103);
            this.livActiveUser.TabIndex = 11;
            this.livActiveUser.UseCompatibleStateImageBehavior = false;
            this.livActiveUser.View = System.Windows.Forms.View.List;
            // 
            // livMember
            // 
            this.livMember.Location = new System.Drawing.Point(426, 210);
            this.livMember.Name = "livMember";
            this.livMember.Size = new System.Drawing.Size(126, 95);
            this.livMember.TabIndex = 11;
            this.livMember.UseCompatibleStateImageBehavior = false;
            this.livMember.View = System.Windows.Forms.View.List;
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.Color.MintCream;
            this.btnQuit.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnQuit.Location = new System.Drawing.Point(12, 266);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(88, 37);
            this.btnQuit.TabIndex = 12;
            this.btnQuit.Text = "QUIT";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnHistory
            // 
            this.btnHistory.BackColor = System.Drawing.Color.MintCream;
            this.btnHistory.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnHistory.Location = new System.Drawing.Point(329, 266);
            this.btnHistory.Name = "btnHistory";
            this.btnHistory.Size = new System.Drawing.Size(89, 37);
            this.btnHistory.TabIndex = 13;
            this.btnHistory.Text = "HISTORY";
            this.btnHistory.UseVisualStyleBackColor = false;
            this.btnHistory.Click += new System.EventHandler(this.btnHistory_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.MintCream;
            this.btnAdd.ForeColor = System.Drawing.Color.SteelBlue;
            this.btnAdd.Location = new System.Drawing.Point(448, 153);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(74, 37);
            this.btnAdd.TabIndex = 14;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lbGroupName
            // 
            this.lbGroupName.AutoSize = true;
            this.lbGroupName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGroupName.ForeColor = System.Drawing.Color.White;
            this.lbGroupName.Location = new System.Drawing.Point(461, 9);
            this.lbGroupName.Name = "lbGroupName";
            this.lbGroupName.Size = new System.Drawing.Size(60, 24);
            this.lbGroupName.TabIndex = 15;
            this.lbGroupName.Text = "label1";
            // 
            // GroupChat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(562, 373);
            this.Controls.Add(this.lbGroupName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnHistory);
            this.Controls.Add(this.livMember);
            this.Controls.Add(this.livActiveUser);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txtInputMessage);
            this.Controls.Add(this.rtxtContentChatGroup);
            this.Name = "GroupChat";
            this.Text = "GroupChat";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GroupChat_FormClosing);
            this.Load += new System.EventHandler(this.GroupChat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtContentChatGroup;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.RichTextBox txtInputMessage;
        private System.Windows.Forms.ListView livActiveUser;
        private System.Windows.Forms.ListView livMember;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnHistory;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lbGroupName;
    }
}