﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatAppClient
{
    public partial class HistoryGroupChat : Form
    {
        GroupChat groupChat;
        string nameGroup;
		private Label lbNameGroup;
		private Label label1;
		private RichTextBox txtHistory;
		ClientSocket Client;
        public HistoryGroupChat( GroupChat _groupChat, string _nameGroup)
        {
            InitializeComponent();
            groupChat = _groupChat;
            nameGroup = _nameGroup;
            Client = groupChat.userForm._loginForm.Client;
            Client.Received += Client_Received;
            lbNameGroup.Text = nameGroup;

        }

        private void Client_Received(ClientSocket cs, string received)
        {
            var message = received.Split('|');
            string mType = message[0];
            string mSender = message[1];
            string mContent = message[2];
            string mRecipient = message[3];
            switch (mType)
            {
                case "ViewHistoryGroupChat":
                    ViewHistoryAction(mContent, mSender, mRecipient);
                    break;
                default:
                    break;
            }
        }

        private void ViewHistoryAction(string mContent, string mSender, string mRecipient)
        {
            if (this.IsHandleCreated)
            {
                Invoke(new Action(() =>
                {
                    if (mRecipient == groupChat.groupName)
                    {
                        if (mSender != groupChat.userName)
                        {
                            //txtHistory.SelectionIndent = 0;
                            //txtHistory.SelectionRightIndent = 170;
                            //txtHistory.SelectedText = mSender + mContent;
                            //txtHistory.AppendText(Environment.NewLine + Environment.NewLine);

                            txtHistory.SelectionIndent = 0;
                            txtHistory.SelectionRightIndent = txtHistory.Width / 2 - 5;
                            txtHistory.SelectionColor = System.Drawing.Color.Magenta;
                            txtHistory.AppendText( mSender +" "+mContent);
                            txtHistory.AppendText(Environment.NewLine + Environment.NewLine);
                        }
                        else
                        {
                            //txtHistory.SelectionIndent = 180;
                            //txtHistory.SelectionRightIndent = 0;
                            //txtHistory.SelectedText = mContent;
                            //txtHistory.AppendText(Environment.NewLine + Environment.NewLine);
                            txtHistory.SelectionIndent = txtHistory.Width / 2 + 5;
                            txtHistory.SelectionRightIndent = 0;
                            txtHistory.SelectionColor = System.Drawing.Color.Teal;
                            txtHistory.AppendText(mContent);
                            txtHistory.AppendText(Environment.NewLine + Environment.NewLine);
                        }
                    }
                }));


            }
        }

        //private void HistoryGroupChat_Load(object sender, EventArgs e)
        //{
        //  //  Client.Send("ViewHistoryGroupChat|" + groupChat.userName + "|" + nameGroup + "|server");
        //}

		private void InitializeComponent()
		{
            this.lbNameGroup = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtHistory = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // lbNameGroup
            // 
            this.lbNameGroup.AutoSize = true;
            this.lbNameGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lbNameGroup.Location = new System.Drawing.Point(243, 11);
            this.lbNameGroup.Name = "lbNameGroup";
            this.lbNameGroup.Size = new System.Drawing.Size(57, 20);
            this.lbNameGroup.TabIndex = 5;
            this.lbNameGroup.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(18, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "MESSAGES HISTORY";
            // 
            // txtHistory
            // 
            this.txtHistory.Location = new System.Drawing.Point(12, 57);
            this.txtHistory.Name = "txtHistory";
            this.txtHistory.Size = new System.Drawing.Size(317, 214);
            this.txtHistory.TabIndex = 3;
            this.txtHistory.Text = "";
            // 
            // HistoryGroupChat
            // 
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(342, 284);
            this.Controls.Add(this.lbNameGroup);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtHistory);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MaximizeBox = false;
            this.Name = "HistoryGroupChat";
            this.Load += new System.EventHandler(this.HistoryGroupChat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

        private void HistoryGroupChat_Load(object sender, EventArgs e)
        {
            Client.Send("ViewHistoryGroupChat|" + groupChat.userName + "|" + nameGroup + "|server");
        }
    }
}
