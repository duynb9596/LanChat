﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatAppClient
{
	public partial class PrivateChat : Form
	{
		public User _userForm;
		string _username;
		public string _target;
		ClientSocket Client;
		byte[] clientData;

		public PrivateChat(User userForm, string username, string target, string firstMessage)
		{
			InitializeComponent();
			_userForm = userForm;
			_username = username;
			_target = target;
			lblUsername.Text = _target;
			_userForm._loginForm.Client.Received += client_Received;
			Client = _userForm.Client;
			LoadAvatar();
			if (firstMessage != "<<null>>")
			{
				txtChatArea.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
				txtChatArea.SelectionIndent = 0;
				txtChatArea.SelectionRightIndent = txtChatArea.Width / 2 - 5;
				txtChatArea.SelectionColor = System.Drawing.Color.Teal;
				txtChatArea.AppendText(firstMessage + Environment.NewLine);
			}
		}

		public void client_Received(ClientSocket cs, string received)
		{
			var message = received.Split('|');
			string mType = message[0];
			string mSender = message[1];
			string mContent = message[2];
			string mRecipient = message[3];
			switch (mType)
			{
				case "PrivateMessage":            
                    PrivateMessageAction(mSender, mContent);
					break;
                case "Disconnect":
                    DisconnectAction(mSender);
                    break;
				case "FileTransfer":
					FileTransferAction(mSender, mRecipient, mContent);
					break;
				case "FileRequest":
					FileRequestAction(mSender, mContent);
					break;
				case "SendFileRequest":
					SendFileRequestAction(mSender, mRecipient, mContent);
					break;
				default:
					break;
			}
		}

		public void SendFileRequestAction(string sender, string recipient, string content)
		{
			Invoke(new Action(() =>
			{
				try
				{
					string messageBoxString = "Would you like to accept file \"" + content + "\" from " + sender + "?";
					DialogResult dialogResult = MessageBox.Show(messageBoxString, "File Request", MessageBoxButtons.YesNo);
					if (dialogResult == DialogResult.Yes)
					{
						Client.Send("FileRequest|" + recipient + "|Accept|" + sender);
					}
					else
					{
						Client.Send("FileRequest|" + recipient + "|Deny|" + sender);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
		}

		private void FileRequestAction(string sender, string content)
		{
			if (content.Equals("Accept"))
			{
				Client.Send("FileTransfer|" + _username + "|" + Encoding.ASCII.GetString(clientData) + "|" + _target);
			}
			else
			{
				MessageBox.Show(sender + " denied to accept file!");
			}
		}

		private void FileTransferAction(string sender, string recipient, string content)
		{
			Invoke(new Action(() =>
			{
				try
				{
					string receivedPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\";
					//string receivedPath = AppDomain.CurrentDomain.BaseDirectory + "FileTransfer\\";
					receivedPath = receivedPath.Replace("\\", "/");
					byte[] clientData = Encoding.ASCII.GetBytes(content);
					int receivedBytesLen = clientData.Length;
					int fileNameLen = BitConverter.ToInt32(clientData, 0);
					string fileName = Encoding.ASCII.GetString(clientData, 4, fileNameLen);
					BinaryWriter bWrite = new BinaryWriter(File.Open(receivedPath + fileName, FileMode.Append));

					bWrite.Write(clientData, 4 + fileNameLen, receivedBytesLen - 4 - fileNameLen);
					bWrite.Close();
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
			}));
		}


		private void DisconnectAction(string sender)
        {
            Invoke(new Action(() =>
            {
                if (lblUsername.Text.ToString() == sender)
                {
                    txtChatArea.AppendText(sender + " has disconnected. Let resend later !!");
                }
            }));          
         
        }

        private void PrivateMessageAction(string Sender,string content)
		{
			if (this.IsHandleCreated)
			{
				Invoke(new Action(() =>
				{
                    if(Sender==_target)
                    {
                        txtChatArea.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Left;
                        txtChatArea.SelectionIndent = 0;
                        txtChatArea.SelectionRightIndent = txtChatArea.Width / 2 - 5;
                        txtChatArea.SelectionColor = System.Drawing.Color.Teal;
                        txtChatArea.AppendText(content + Environment.NewLine);
                    }
					
				}));
			}                            
        }

		private void btnSend_Click(object sender, EventArgs e)
		{
            if (txtInputMessage.Text != "")
            {

                string message = "PrivateMessage|" + _username + "|" + txtInputMessage.Text + "|" + _target;
				Client.Send(message);
				txtChatArea.SelectionAlignment = System.Windows.Forms.HorizontalAlignment.Right;
				txtChatArea.SelectionIndent = txtChatArea.Width / 2 + 5;
				txtChatArea.SelectionRightIndent = 0;
                txtChatArea.AppendText(txtInputMessage.Text + Environment.NewLine);
                txtInputMessage.Text = "";
            }
            else
                MessageBox.Show("Empty Message!");
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            HistoryChat historyChat = new HistoryChat(this,_username, _target);
            historyChat.Show();
        }

		private void btnChooseFile_Click(object sender, EventArgs e)
		{
			string path;
			OpenFileDialog file = new OpenFileDialog();
			if (file.ShowDialog() == DialogResult.OK)
			{
				path = file.FileName;
				txtFileName.Text = path;
			}
		}

		private void btnSendFile_Click(object sender, EventArgs e)
		{
			try
			{
				var filePath = txtFileName.Text.Split('\\');
				string fileName = txtFileName.Text;
				byte[] fileData = File.ReadAllBytes(fileName);
				fileName = filePath[filePath.Length - 1];
				byte[] fileNameByte = Encoding.ASCII.GetBytes(fileName);
				clientData = new byte[4 + fileNameByte.Length + fileData.Length];
				byte[] fileNameLen = BitConverter.GetBytes(fileNameByte.Length);

				fileNameLen.CopyTo(clientData, 0);
				fileNameByte.CopyTo(clientData, 4);
				fileData.CopyTo(clientData, 4 + fileNameByte.Length);

				Client.Send("SendFileRequest|" + _username + "|" + fileName + "|" + _target);
				//Client.Send("FileTransfer|" + _username + "|" + Encoding.ASCII.GetString(clientData) + "|" + _target);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}	
		}

		private void PrivateChat_FormClosed(object sender, FormClosedEventArgs e)
		{
			_userForm.listPrivateChat.Remove(this);
		}

		public Bitmap ResizeImage(Image image, int width, int height)
		{
			var destRect = new Rectangle(0, 0, width, height);
			var destImage = new Bitmap(width, height);

			destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

			using (var graphics = Graphics.FromImage(destImage))
			{
				graphics.CompositingMode = CompositingMode.SourceCopy;
				graphics.CompositingQuality = CompositingQuality.HighQuality;
				graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
				graphics.SmoothingMode = SmoothingMode.HighQuality;
				graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

				using (var wrapMode = new ImageAttributes())
				{
					wrapMode.SetWrapMode(WrapMode.TileFlipXY);
					graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
				}
			}

			return destImage;
		}

		protected void LoadAvatar()
		{
			string avatar_path = @"Avatar\" + _target.ToLower() + "_avatar.jpeg";
			picAvatar.Image = ResizeImage(Image.FromFile(avatar_path), picAvatar.Width, picAvatar.Height);
		}

		private void txtInputMessage_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter)
			{
				btnSend_Click(sender, e);
			}
		}
	}
}
